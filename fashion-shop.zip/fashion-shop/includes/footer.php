    <footer class="py-4 bg-dark text-white text-center">
      <div class="container">
        <p class="mb-0">&copy; <?= date('Y') ?> Toko Baju. Dibuat oleh Tim Dev.</p>
      </div>
    </footer>

<!-- Bootstrap 5 JS -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
